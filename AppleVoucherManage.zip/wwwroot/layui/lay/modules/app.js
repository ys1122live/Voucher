﻿layui.define(["jquery", "layer", "form", 'laydate', "upload"],function(exports) {
    var $ = layui.jquery;
    var layer = layui.layer;
    var form = layui.form;
    var laydate = layui.laydate;

    var app = {
    };

    window.onhashchange = function () {
        var loading = layer.load(2);
        //请求模板
        $.ajax({
            url: layui.router().href,
            type: 'get',
            dataType: 'html',
            success: function (html) {
                $("#LAY_app_body").html('');
                $("#LAY_app_body").html(html);
                $("#LAY_app_body").find("*[date]").each(function (index, element) {
                    laydate.render({
                        elem: element,
                        type: "datetime",
                        format: "yyyy-MM-dd HH:mm:ss"
                    });
                });
                form.render();
            },
            error: function (e) {
                if (e.status == 401) {
                    window.location.href = e.responseText;
                } else {
                    layer.alert('加载失败', { title: '提示', shadeClose: true });
                }
            },
            complete: function () {
                layer.close(loading);
            }
        });
    };

    $("body").on("click",
        "*[dialog]",
        function () {
            var item = $(this);
            var option = {
                type: 1,
                shadeClose: true,
                success: function (layero) {
                    //刷新表单项目渲染
                    form.render();
                }
            };

            var url = item.attr("dialog");
            if (item.data().hasOwnProperty("param")) {
                url += "&" + item.data("param");
            }

            var title = item.data("title");
            if (!title) {
                title = item.html();
            }
            option.title = title;

            if (item.data().hasOwnProperty("area")) {
                option.area = item.data("area");
            }

            $.ajax({
                url: url,
                beforeSend: function () {
                    layer.load();
                },
                success: function (data) {
                    if (typeof data == "object") {
                        if ('msg' in data) {
                            layer.alert(data.msg, { title: '提示', shadeClose: true });
                        } else {
                            layer.alert("加载失败", { title: '提示', shadeClose: true });
                        }
                    } else if (typeof data == "string") {
                        option.content = data;
                        layer.open(option);
                   } else {
                        layer.alert("加载失败", { title: '提示', shadeClose: true });
                    }
                },
                error: function (e) {
                    if (e.status == 401) {
                        window.location.href = e.responseText;
                    } else {
                        layer.alert('加载失败', { title: '提示', shadeClose: true });
                    }
                },
                complete: function () {
                    layer.closeAll('loading');
                }
            });
        });

    $("body").on("click",
        "*[confirm]",
        function () {
            var item = $(this);

            var url = item.attr("confirm");

            var title = item.data("title");
            if (!title) {
                title = "确定要执行此操作吗?";
            }

            layer.confirm(title,
                function(index) {
                    layer.close(index);
                    $.ajax({
                        url: url,
                        beforeSend: function() {
                            layer.load();
                        },
                        success: function(data) {
                            if (typeof data == "object") {
                                if (data == null) {
                                    layer.alert("执行失败", { title: '提示', shadeClose: true });
                                } else if (data.result) {
                                    layer.alert(data.msg, { title: '提示', shadeClose: true, end: function() {
                                        window.onhashchange();
                                    }});
                                } else {
                                    layer.alert(data.msg, { title: '提示', shadeClose: true });
                                }
                            } else {
                                layer.alert("执行异常", { title: '提示', shadeClose: true });
                            }
                        },
                        error: function (e) {
                            if (e.status == 401) {
                                window.location.href = e.responseText;
                            } else {
                                layer.alert('加载失败', { title: '提示', shadeClose: true });
                            }
                        },
                        complete: function() {
                            layer.closeAll('loading');
                        }
                    });
                });
        });

    $("body").on("click",
        "*[loading]",
        function () {
            var item = $(this);

            var url = item.attr("loading");

            $.ajax({
                url: url,
                beforeSend: function () {
                    layer.load();
                },
                success: function (data) {
                    if (typeof data == "object") {
                        if (data == null) {
                            layer.alert("执行失败", { title: '提示', shadeClose: true });
                        } else if (data.result) {
                            window.onhashchange();
                        } else {
                            layer.alert(data.msg, { title: '提示', shadeClose: true });
                        }
                    } else {
                        layer.alert("执行异常", { title: '提示', shadeClose: true });
                    }
                },
                error: function (e) {
                    if (e.status == 401) {
                        window.location.href = e.responseText;
                    } else {
                        layer.alert('加载失败', { title: '提示', shadeClose: true });
                    }
                },
                complete: function () {
                    layer.closeAll('loading');
                }
            });
        });

    form.verify({
        radiorequired: function (value, item) {
            if ($("[name='"+item.name+"']:checked").length < 1) {
                return "必填项不能为空";
            }
        },
        checkboxrequired: function (value, item) {
            if ($("[name='" + item.name + "']:checked").length < 1) {
                return "必填项不能为空";
            }
        },
        filterquired: function (value, item) {
            if ($("input[lay-filter='" + item.attributes["lay-filter"].value +"']:checked").length < 1) {
                return "必填项不能为空";
            }
        },
        length: function (value) {
            if (value.length < 6) {
                return "密码至少6位";
            }
        },
        same: function (value, item) {
            if ($('input[name=' + item.name.replace('re', '') + ']').val() !== value) {
                return "两次密码输入不一致";
            }
        }
    });

    form.on("submit(search)",
        function (data) {
            var href = layui.router().href;
            href = href.split("?")[0];
            href = href + "?" + $.param(data.field);
            if (href === layui.router().href) {
                window.onhashchange();
            } else {
                location.hash = href;
            }
            return false;
        });


    form.on("submit(normal)",
        function (data) {
            $.ajax({
                type: "POST",
                url: data.form.action,
                data: data.field,
                beforeSend: function() {
                    layer.load();
                },
                success: function(data) {
                    if (data && typeof data == "object") {
                        if (data.result) {
                            layer.closeAll('page');
                            layer.alert(data.msg, { title: '提示', shadeClose: true, end: function () {
                                    window.onhashchange();
                                }
                            });
                        } else {
                            layer.alert(data.msg, { title: '提示', shadeClose: true });
                        }
                    } else {
                        layer.alert("执行异常", { title: '提示', shadeClose: true });
                    }
                },
                error: function (e) {
                    if (e.status == 401) {
                        window.location.href = e.responseText;
                    } else {
                        layer.alert('加载失败', { title: '提示', shadeClose: true });
                    }
                },
                complete: function() {
                    layer.closeAll('loading');
                }
            });

            return false;
        });
    exports("app", app);
});