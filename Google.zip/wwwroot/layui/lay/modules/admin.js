layui.define(function (exports) {
    var $ = layui.jquery;
    var $win = $(window);
    var $body = $('body');
    var element = layui.element;

    var admin = {
        screen: function () {
            var width = $(window).width();
            return width > 1200 ? 3 : width > 992 ? 2 : width > 768 ? 1 : 0;
        },
        sideFlexible: function (e) {
            var app = $("#LAY_app");
            var flexible = $("#LAY_app_flexible");
            if ("spread" === e) {
                flexible.removeClass("layui-icon-spread-left").addClass("layui-icon-shrink-right");
                if (admin.screen() < 2) {
                    app.addClass("layadmin-side-spread-sm");
                } else {
                    app.removeClass("layadmin-side-spread-sm");
                }
                app.removeClass("layadmin-side-shrink");
            } else {
                flexible.removeClass("layui-icon-shrink-right").addClass("layui-icon-spread-left");
                if (admin.screen() < 2) {
                    app.removeClass("layadmin-side-shrink");
                } else {
                    app.addClass("layadmin-side-shrink");
                }
                app.removeClass("layadmin-side-spread-sm");
            }
        }
    }

    //监听侧边导航点击事件
    element.on('nav(layadmin-system-side-menu)', function (elem) {
        admin.sideFlexible("spread");
    });



    window.onload = function () {
        if (layui.router().href) {
            var href = layui.router().href;
            var s = href.indexOf('?');
            if (s > -1) href = href.substr(0, s);
            var menu = $("a[data-opt=menu][lay-href='" + href + "']");
            if (menu.length > 0) {
                menu.parent("dd").addClass("layui-this");
                menu.parents("li").addClass("layui-nav-itemed");
            }

            window.onhashchange();
        }
    }

    $body.on("click",
        "*[lay-href]",
        function () {
            var href = $(this).attr('lay-href');
            if (location.hash === "#" + href) {
                window.onhashchange();
            } else {
                location.hash = href;
            }

            if ($("#LAY_app").hasClass("layadmin-side-spread-sm")) {
                admin.sideFlexible();
            };
        });


    $body.on("click",
        "*[flexible]",
        function () {
            admin.sideFlexible($("#LAY_app_flexible").hasClass("layui-icon-spread-left") ? "spread" : null);
        });

    //窗口resize事件
    var resizeSystem = layui.data.resizeSystem = function () {
        if (!resizeSystem.lock) {
            setTimeout(function () {
                admin.sideFlexible(admin.screen() < 2 ? '' : 'spread');
                delete resizeSystem.lock;
            }, 100);
        }

        resizeSystem.lock = true;
    }
    $win.on('resize', layui.data.resizeSystem);

    if (admin.screen() < 2) {
        admin.sideFlexible();
    }
    exports("admin", admin);
});